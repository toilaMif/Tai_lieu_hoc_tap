package bai14;

public class Product {
	private String productID;
    private String description;
    private double price;

    /**
     * Constructor khởi tạo một sản phẩm với các thông tin cần thiết.
     *
     * @param productID   Mã sản phẩm.
     * @param description Mô tả về sản phẩm.
     * @param price       Giá của sản phẩm.
     */
    public Product(String productID, String description, double price) {
        this.productID = productID;
        this.description = description;
        this.price = price;
    }

    /**
     * Phương thức trả về mã sản phẩm.
     *
     * @return Mã sản phẩm.
     */
    public String getProductID() {
        return productID;
    }

    /**
     * Phương thức trả về mô tả về sản phẩm.
     *
     * @return Mô tả về sản phẩm.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Phương thức trả về giá của sản phẩm.
     *
     * @return Giá của sản phẩm.
     */
    public double getPrice() {
        return price;
    }

}
