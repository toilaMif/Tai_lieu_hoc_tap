package bai14;

import java.time.LocalDate;

public class Program14 {
	public class Main {
	    public static void main(String[] args) {
	        Product product1 = new Product("sp4", "Nước Tương", 8000);
	        Product product2 = new Product("sp1", "Gạo", 18000);
			Product product3 = new Product("sp3", "Đường", 10000);
	        Product product4 = new Product("sp1", "Gạo", 18000);

	        Order order = new Order(1, LocalDate.of(2015, 9, 10));

	        order.addLineItem(product1, 10);
	        order.addLineItem(product2, 5);
			order.addLineItem(product3, 1);
	        order.addLineItem(product4, 1);

	        System.out.println(order.toString());
	        }
}
}


