package bai14;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Order {
	private int orderID;
    private LocalDate orderDate;
    private List<OrderDetail> lineItems;

    /**
     * Constructor khởi tạo một đơn đặt hàng với mã đơn hàng và ngày đặt hàng.
     *
     * @param orderID   Mã đơn hàng.
     * @param orderDate Ngày đặt hàng.
     */
    public Order(int orderID, LocalDate orderDate) {
        this.orderID = orderID;
        this.orderDate = orderDate;
        this.lineItems = new ArrayList<>();
    }

    /**
     * Phương thức thêm một chi tiết đơn đặt hàng vào đơn đặt hàng.
     *
     * @param product  Sản phẩm được thêm vào đơn đặt hàng.
     * @param quantity Số lượng sản phẩm.
     */
    public void addLineItem(Product product, int quantity) {
        lineItems.add(new OrderDetail(product, quantity));
    }

    /**
     * Phương thức tính tổng giá của toàn bộ đơn đặt hàng.
     *
     * @return Tổng giá của đơn đặt hàng.
     */
    public double calcTotalCharge() {
        double totalCharge = 0;
        for (OrderDetail item : lineItems) {
            totalCharge += item.calcTotalPrice();
        }
        return totalCharge;
    }

    /**
     * Phương thức xuất thông tin chi tiết của đơn đặt hàng dưới dạng chuỗi.
     *
     * @return Chuỗi chứa thông tin chi tiết đơn đặt hàng.
     */
    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        result.append("Mã HĐ: ").append(orderID).append("\n");
        result.append("Ngày lập hóa đơn: ").append(orderDate).append("\n");
        result.append("STT     | Mã SP   | Mô tả        | Đơn giá   | S Lượng   | Thành tiền\n");

        int stt = 1;
        for (OrderDetail item : lineItems) {
            result.append(String.format("%-8d| %-8s| %-13s| %-10.2f| %-10d| %10.2f VND\n",
                    stt++, item.getProduct().getProductID(), item.getProduct().getDescription(),
                    item.getProduct().getPrice(), item.getQuantity(), item.calcTotalPrice()));
        }

        result.append("Tổng tiền hóa đơn: ").append(calcTotalCharge()).append(" VND\n");

        return result.toString();
    }
}
