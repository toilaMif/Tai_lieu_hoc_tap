package bai14;

public class OrderDetail {
	private int quantity;
    private Product product;

    /**
     * Constructor khởi tạo một chi tiết đơn đặt hàng với sản phẩm và số lượng.
     *
     * @param product  Sản phẩm trong chi tiết đơn đặt hàng.
     * @param quantity Số lượng sản phẩm.
     */
    public OrderDetail(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    /**
     * Phương thức tính tổng giá của chi tiết đơn đặt hàng.
     *
     * @return Tổng giá của chi tiết đơn đặt hàng.
     */
    public double calcTotalPrice() {
        return quantity * product.getPrice();
    }

    /**
     * Phương thức trả về số lượng sản phẩm trong chi tiết đơn đặt hàng.
     *
     * @return Số lượng sản phẩm.
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * Phương thức trả về thông tin về sản phẩm trong chi tiết đơn đặt hàng.
     *
     * @return Sản phẩm trong chi tiết đơn đặt hàng.
     */
    public Product getProduct() {
        return product;
    }

}
