package bai15;

import java.util.ArrayList;

public class QuanLyHocVien {
	private ArrayList<DiemHocVien> danhSachHocVien;

    public QuanLyHocVien() {
        danhSachHocVien = new ArrayList<>();
    }

    public void themHocVien(DiemHocVien hocVien) {
        danhSachHocVien.add(hocVien);
    }

    public int soLuongLamLuanVan() {
        int count = 0;
        for (DiemHocVien hocVien : danhSachHocVien) {
            if (hocVien.lamLuanVan()) {
                count++;
            }
        }
        return count;
    }

    public int soLuongThiTotNghiep() {
        int count = 0;
        for (DiemHocVien hocVien : danhSachHocVien) {
            if (hocVien.thiTotNghiep()) {
                count++;
            }
        }
        return count;
    }

    public int soLuongThiLai() {
        int count = 0;
        for (DiemHocVien hocVien : danhSachHocVien) {
            if (hocVien.thiLai()) {
                count++;
            }
        }
        return count;
    }

    public void inDanhSachThiLai() {
        for (DiemHocVien hocVien : danhSachHocVien) {
            if (hocVien.thiLai()) {
                System.out.println("Học viên: " + hocVien.getHoTen() + " - Môn thi lại: " + hocVien.monThiLai());
            }
        }
    }

}
