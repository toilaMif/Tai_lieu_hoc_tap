package bai15;

public class Program15 {
	public class Main {
	    public static void main(String[] args) {
	        QuanLyHocVien qlhv = new QuanLyHocVien();
	        
	        qlhv.themHocVien(new DiemHocVien("Nguyen A", 1990, new double[]{7.0, 8.0, 9.0, 7.5, 8.5}));
	        qlhv.themHocVien(new DiemHocVien("Tran B", 1991, new double[]{6.0, 7.0, 6.5, 7.0, 6.5}));
	        qlhv.themHocVien(new DiemHocVien("Le C", 1992, new double[]{8.0, 9.0, 8.5, 9.0, 8.5}));
	        qlhv.themHocVien(new DiemHocVien("Pham D", 1993, new double[]{4.0, 5.0, 4.5, 5.0, 4.5}));
	        qlhv.themHocVien(new DiemHocVien("Hoang E", 1994, new double[]{7.0, 8.0, 7.5, 8.0, 7.5}));

	        System.out.println("Số lượng học viên làm luận văn: " + qlhv.soLuongLamLuanVan());
	        System.out.println("Số lượng học viên thi tốt nghiệp: " + qlhv.soLuongThiTotNghiep());
	        System.out.println("Số lượng học viên thi lại: " + qlhv.soLuongThiLai());

	        System.out.println("Danh sách học viên thi lại:");
	        qlhv.inDanhSachThiLai();
	    }
	}

}
