package bai15;

public class DiemHocVien {
	 	private String hoTen;
	    private int namSinh;
	    private double[] diemMonHoc = new double[5];

	    public DiemHocVien(String hoTen, int namSinh, double[] diemMonHoc) {
	        this.hoTen = hoTen;
	        this.setNamSinh(namSinh);
	        System.arraycopy(diemMonHoc, 0, this.diemMonHoc, 0, diemMonHoc.length);
	    }
	    public String getHoTen() {
	    	return hoTen;
		}
	    public int getnamSinh() {
	    	return namSinh;
		}
	    

	    public double tinhDiemTrungBinh() {
	        double tongDiem = 0;
	        for (double diem : diemMonHoc) {
	            tongDiem += diem;
	        }
	        return tongDiem / diemMonHoc.length;
	    }

	    public boolean lamLuanVan() {
	        if (tinhDiemTrungBinh() > 7) {
	            for (double diem : diemMonHoc) {
	                if (diem < 5) {
	                    return false;
	                }
	            }
	            return true;
	        }
	        return false;
	    }

	    public boolean thiTotNghiep() {
	        if (tinhDiemTrungBinh() <= 7) {
	            for (double diem : diemMonHoc) {
	                if (diem < 5) {
	                    return false;
	                }
	            }
	            return true;
	        }
	        return false;
	    }

	    public boolean thiLai() {
	        for (double diem : diemMonHoc) {
	            if (diem < 5) {
	                return true;
	            }
	        }
	        return false;
	    }

	    public String monThiLai() {
	        StringBuilder sb = new StringBuilder();
	        String[] tenMonHoc = {"Toán", "Lý", "Hóa", "Sinh", "Tiếng Anh"};
	        for (int i = 0; i < diemMonHoc.length; i++) {
	            if (diemMonHoc[i] < 5) {
	                sb.append(tenMonHoc[i]).append(" ");
	            }
	        }
	        return sb.toString();
	    }
		public int getNamSinh() {
			return namSinh;
		}
		public void setNamSinh(int namSinh) {
			this.namSinh = namSinh;
		}

}
