package bai03;

import java.util.Scanner;

public class Program3 {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Nhap ban kinh: ");
		double ban_kinh = sc.nextDouble();
		
		System.out.println("Nhap chieu cao: ");
		double chieu_cao = sc.nextDouble();
		
		Cylinder tru = new Cylinder(ban_kinh, chieu_cao);
		
		//2pirh
		System.out.println("Dien tich xung quanh " + tru.dien_tich_xung_quanh());
		//2pirh + 2pirr
		System.out.println("Dien tich toan phan " +  tru.dien_tich_toan_phan());
		//pirrh
		System.out.println("The tich hinh tru " + tru.the_tich());
	}
	

}
