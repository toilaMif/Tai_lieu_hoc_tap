package bai03;

public class Cylinder {
 private double ban_kinh;
 private double chieu_cao;
 

 public Cylinder(double ban_kinh, double chieu_cao) {
	this.ban_kinh = ban_kinh;
	this.chieu_cao = chieu_cao;
}
 public double dien_tich_xung_quanh() {
	 return 2*Math.PI*ban_kinh*chieu_cao;
	
}
 public double dien_tich_toan_phan() {
	 return 2*Math.PI*ban_kinh*chieu_cao + 2*Math.PI*ban_kinh*ban_kinh;
 
}
 public double the_tich() {
	 return Math.PI*ban_kinh*ban_kinh*chieu_cao;
}
}
