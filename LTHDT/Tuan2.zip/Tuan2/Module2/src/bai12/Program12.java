package bai12;

import java.util.Scanner;

public class Program12 {
    public static void main(String[] args) {
    	CDList cdList = new CDList(10);  // Khởi tạo danh sách CD với tối đa 10 phần tử
        
        cdList.themCD(new CD(123, "Nhac", 10, 10000));
        cdList.themCD(new CD(124, "Phim", 20, 20000));
        cdList.themCD(new CD(125, "Nhac2", 30, 30000));
        
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("1. Thêm CD");
            System.out.println("2. Xóa CD");
            System.out.println("3. Tìm kiếm CD");
            System.out.println("4. Tính tổng giá thành");
            System.out.println("5. Sắp xếp giảm dần theo giá thành");
            System.out.println("6. Sắp xếp tăng dần theo tựa CD");
            System.out.println("7. Xem thông tin CD");
            System.out.println("0. Thoát");
            System.out.print("Nhập lựa chọn của bạn: ");
            choice = scanner.nextInt();

            switch (choice) {
            case 1:
                // Thêm CD
                System.out.println("Nhập mã CD: ");
                int maCD = scanner.nextInt();
                scanner.nextLine();  
                System.out.println("Nhập tựa CD: ");
                String tuaCD = scanner.nextLine();
                System.out.println("Nhập số bài hát: ");
                int soBaiHat = scanner.nextInt();
                System.out.println("Nhập giá thành: ");
                double giaThanh = scanner.nextDouble();
                CD cd = new CD(maCD, tuaCD, soBaiHat, giaThanh);
                cdList.themCD(cd);
                break;
            case 2:
                // Xóa CD
                System.out.println("Nhập mã CD cần xóa: ");
                int maCDXoa = scanner.nextInt();
                cdList.xoaCD(maCDXoa);
                break;
            case 3:
                // Tìm kiếm CD
            	System.out.println("Nhập mã CD cần tìm: ");
            	int maCDTim = scanner.nextInt();
            	CD cdTim = cdList.timKiem(maCDTim);
            	if (cdTim != null) {
            	    System.out.println("Thông tin của CD cần tìm:");
            	    System.out.println("Mã CD: " + cdTim.getMaCD());
            	    System.out.println("Tựa CD: " + cdTim.getTuaCD());
            	    System.out.println("Số bài hát: " + cdTim.getSoBaiHat());
            	    System.out.println("Giá thành: " + cdTim.getGiaThanh());
            	} else {
            	    System.out.println("Không tìm thấy CD với mã " + maCDTim + ".");
            	}
            	break;

            case 4:
                // Tính tổng giá thành
                double tongGiaThanh = cdList.tongGiaThanh();
                System.out.println("Tổng giá thành: " + tongGiaThanh);
                break;
            case 5:
                // Sắp xếp giảm dần theo giá thành
                cdList.sapXepGiamDanTheoGiaThanh();
                System.out.println("Danh sách sau khi sắp xếp giảm dần theo giá thành: ");
                System.out.println(cdList.toString());
                break;
            case 6:
                // Sắp xếp tăng dần theo tựa CD
                cdList.sapXepTangDanTheoTuaCD();
                System.out.println("Danh sách sau khi sắp xếp tăng dần theo tựa CD: ");
                System.out.println(cdList.toString());
                break;
            case 7:
                // Xem thông tin CD
                System.out.println("Thông tin của tất cả các CD trong danh sách: ");
                System.out.println(cdList.toString());
                break;

            case 0:
                System.out.println("Thoát chương trình.");
                break;
            default:
                System.out.println("Lựa chọn không hợp lệ. Vui lòng thử lại.");
        }

        } while (choice != 0);

        scanner.close();
    }
}

