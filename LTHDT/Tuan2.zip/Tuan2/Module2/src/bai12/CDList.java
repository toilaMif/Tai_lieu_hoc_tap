package bai12;

public class CDList {
	private CD[] cds;
    private int count = 0;

    public CDList(int n) {
        cds = new CD[n];
    }

    public void themCD(CD cd) {
        if (count < cds.length) {
            for (int i = 0; i < count; i++) {
                if (cds[i].getMaCD() == cd.getMaCD()) {
                    return;
                }
            }
            cds[count++] = cd;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            sb.append("CD " + (i + 1) + ":\n");
            sb.append("Mã CD: " + cds[i].getMaCD() + "\n");
            sb.append("Tựa CD: " + cds[i].getTuaCD() + "\n");
            sb.append("Số bài hát: " + cds[i].getSoBaiHat() + "\n");
            sb.append("Giá thành: " + cds[i].getGiaThanh() + "\n");
            sb.append("--------------------\n");
        }
        return sb.toString();
    }

    public void xoaCD(int maCD) {
        for (int i = 0; i < count; i++) {
            if (cds[i].getMaCD() == maCD) {
                for (int j = i; j < count - 1; j++) {
                    cds[j] = cds[j + 1];
                }
                cds[--count] = null;
                break;
            }
        }
    }

    public double tongGiaThanh() {
        double tong = 0;
        for (int i = 0; i < count; i++) {
            tong += cds[i].getGiaThanh();
        }
        return tong;
    }

    public CD timKiem(int maCD) {
        for (int i = 0; i < count; i++) {
            if (cds[i].getMaCD() == maCD) {
                return cds[i];
            }
        }
        return null;
    }

    public void sapXepGiamDanTheoGiaThanh() {
        for (int i = 0; i < count - 1; i++) {
            for (int j = i + 1; j < count; j++) {
                if (cds[i].getGiaThanh() < cds[j].getGiaThanh()) {
                    CD temp = cds[i];
                    cds[i] = cds[j];
                    cds[j] = temp;
                }
            }
        }
    }

    public void sapXepTangDanTheoTuaCD() {
        for (int i = 0; i < count - 1; i++) {
            for (int j = i + 1; j < count; j++) {
                if (cds[i].getTuaCD().compareTo(cds[j].getTuaCD()) > 0) {
                    CD temp = cds[i];
                    cds[i] = cds[j];
                    cds[j] = temp;
                }
            }
        }
    }
}
