package bai04;

import java.util.Scanner;

import bai02.Point;

public class Program4 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("nhap Ma Sinh Vien:");
		int maSinhVien =sc.nextInt();
		sc.nextLine();
		System.out.println("nhap Ho Ten:");
		String hoTen =sc.nextLine();
		
		System.out.println("nhap diem ly thuyet:");
		double diemLT =sc.nextDouble();
		sc.nextLine();
		System.out.println("nhap thuc hanh:");
		double diemTH =sc.nextDouble();
		
		System.out.printf("%-10s %-30s  %s  %s  %s\n", "maSinhVien", "hoTen", "diemLT", "diemTH", "DiemTrungBinh");
		DiemSinhVien sv1 = new DiemSinhVien(22696701,"Nguyen Thanh Trung", 10, 10);
		System.out.println(sv1.toString());
		DiemSinhVien sv2 = new DiemSinhVien(22696241,"Thai Van Trung", 9, 9.5);
		System.out.println(sv2.toString());
		DiemSinhVien sv3 = new DiemSinhVien(maSinhVien, hoTen, diemLT, diemTH);
		System.out.println(sv3.toString());
		
		
		
	}

}
