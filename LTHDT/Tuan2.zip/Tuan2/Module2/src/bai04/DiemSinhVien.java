package bai04;

public class DiemSinhVien {
	
	    private int maSinhVien;
	    private String hoTen;
	    private double diemLT;
	    private double diemTH;

	   
	    public DiemSinhVien() {
	        this.maSinhVien = 0;
	        this.hoTen = "";
	        this.diemLT = 0;
	        this.diemTH = 0;
	    }

	   
	    public DiemSinhVien(int maSinhVien, String hoTen, double diemLT, double diemTH) {
	        this.maSinhVien = (maSinhVien > 0) ? maSinhVien : 0;
	        this.hoTen = (hoTen != null && !hoTen.isEmpty()) ? hoTen : "";
	        this.diemLT = (diemLT >= 0.0 && diemLT <= 10.0) ? diemLT : 0;
	        this.diemTH = (diemTH >= 0.0 && diemTH <= 10.0) ? diemTH : 0;
	    }

	    
	    public int getMaSinhVien() {
	        return maSinhVien;
	    }

	    public void setMaSinhVien(int maSinhVien) {
	        this.maSinhVien = (maSinhVien > 0) ? maSinhVien : this.maSinhVien;
	    }

	    public String getHoTen() {
	        return hoTen;
	    }

	    public void setHoTen(String hoTen) {
	        this.hoTen = (hoTen != null && !hoTen.isEmpty()) ? hoTen : this.hoTen;
	    }

	    public double getDiemLT() {
	        return diemLT;
	    }

	    public void setDiemLT(double diemLT) {
	        this.diemLT = (diemLT >= 0.0 && diemLT <= 10.0) ? diemLT : this.diemLT;
	    }

	    public double getDiemTH() {
	        return diemTH;
	    }

	    public void setDiemTH(double diemTH) {
	        this.diemTH = (diemTH >= 0.0 && diemTH <= 10.0) ? diemTH : this.diemTH;
	    }

	    public double tinhDiemTrungBinh() {
	        return (diemLT + diemTH) / 2;
	    }

	    public String toString() {
	        return String.format("%-10d %-30s   %5.2f   %5.2f   %5.2f", maSinhVien, hoTen, diemLT, diemTH, tinhDiemTrungBinh());
	    }
}


