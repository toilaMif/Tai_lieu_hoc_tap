package bai11;

import java.time.LocalDate;

public class KhachHang {
    private String maKH;
    private String hoTenKH;
    private SoTietKiem[] dsSoTietKiem;
    private int soLuongSoHienCo;

    public KhachHang(String maKH, int soLuongSoHemCo) {
        this.maKH = maKH;
        this.soLuongSoHienCo = soLuongSoHemCo;
        this.dsSoTietKiem = new SoTietKiem[soLuongSoHemCo];
    }

    public boolean themSoTietKiem(String maSo, LocalDate ngayMoSo, double soTienGoi, int kyHan, float laiSuat) {
        if (soLuongSoHienCo < dsSoTietKiem.length) {
            dsSoTietKiem[soLuongSoHienCo] = new SoTietKiem(maSo, ngayMoSo, soTienGoi, kyHan, laiSuat);
            soLuongSoHienCo++;
            return true;
        } else {
            return false;
        }
    }

    public String toString() {
        String result = "Khach Hang: " 
                + maKH + ' ' +'-' +  ' ' +
                hoTenKH ;
        for (int i = 0; i < soLuongSoHienCo; i++) {
            if (dsSoTietKiem[i] != null) {
                result += "\n" + dsSoTietKiem[i].toString();
            }
        }
        return result;
    }
    

    public String getMaKH() {
        return this.maKH;
    }

    public String getHoTenKH() {
        return this.hoTenKH;
    }

    public SoTietKiem[] getDsSoTietKiem() {
        return this.dsSoTietKiem;
    }

    public int getSoLuongSoHienCo() {
        return this.soLuongSoHienCo;
    }

    public void setHoTenKH(String hoTenKH) {
        this.hoTenKH = hoTenKH;
    }
}
