package bai11;

import java.time.LocalDate;

public class Program11 {
    public static void main(String[] args) {
        // Tạo một đối tượng KhachHang mới với mã KH01, tên là Nguyen Van A và có 5 sổ tiết kiệm
        KhachHang khachHang = new KhachHang("KH01", 5);
        khachHang.setHoTenKH("Nguyen Van A");

        // Tạo một sổ tiết kiệm mới và thiết lập các thuộc tính cho nó
        SoTietKiem soTietKiem = new SoTietKiem();
        soTietKiem.setMaSo("STK01");
        soTietKiem.setNgayMoSo(LocalDate.of(2023, 5, 1));
        soTietKiem.setSoTienGoi(1000000);
        soTietKiem.setKyHan(3);
        soTietKiem.setLaiSuat(0.005f);

        // Thêm sổ tiết kiệm vào danh sách sổ tiết kiệm của khách hàng
        khachHang.themSoTietKiem(soTietKiem.getMaSo(), soTietKiem.getNgayMoSo(), soTietKiem.getSoTienGoi(), soTietKiem.getKyHan(), soTietKiem.getLaiSuat());

        // In ra số tháng gởi thực của sổ tiết kiệm
        System.out.println("So thang goi thuc: " + soTietKiem.tinhSoThangGoiThuc());

        // In ra thông tin của khách hàng
        System.out.println(khachHang.toString());

        // In ra thông tin STK
        System.out.println(soTietKiem.toString());

    }
}
