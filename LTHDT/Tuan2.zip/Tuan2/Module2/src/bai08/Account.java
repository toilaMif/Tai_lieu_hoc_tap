package bai08;

import java.text.NumberFormat;
import java.util.Locale;

public class Account {
	 private final long accountNumber;
	    private String name;
	    private double balance;
	    private static final double RATE = 0.035;

	    public Account() {
	        this.accountNumber = 999999;
	        this.name = "chưa xác định";
	        this.balance = 50000;
	    }

	    public Account(long accountNumber, String name, double balance) {
	        this.accountNumber = accountNumber > 0 ? accountNumber : 999999;
	        this.name = !name.isEmpty() ? name : "chưa xác định";
	        this.balance = balance >= 50000 ? balance : 50000;
	    }

	    public Account(long accountNumber, String name) {
	        this(accountNumber, name, 50000);
	    }

	    public long getAccountNumber() {
	        return accountNumber;
	    }

	    public double getBalance() {
	        return balance;
	    }

	    public boolean deposit(double amount) { //them tien gui
	        if (amount > 0) {
	            this.balance += amount;
	            return true;
	        }
	        return false;
	    }

	    public boolean withdraw(double amount, double fee) { // rut tien
	        if (amount > 0 && amount + fee <= balance) {
	            this.balance -= (amount + fee);
	            return true;
	        }
	        return false;
	    }

	    public void addInterest() { //tinh tien lai
	        this.balance += this.balance * RATE;
	    }

	    public boolean transfer(Account acc2, double amount) { //chuyen tien
	        if (this.withdraw(amount, 0)) {
	            acc2.deposit(amount);
	            return true;
	        }
	        return false;
	    }

	    @Override
	    public String toString() {
	        Locale local = new Locale("vi", "vn");
	        NumberFormat formatter = NumberFormat.getCurrencyInstance(local);
	        return "AccountNumber: " + accountNumber + ", Name: " + name + ", Balance: " + formatter.format(balance);
	    }
	}

