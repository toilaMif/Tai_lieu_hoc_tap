package bai01;

import java.util.Scanner;

public class Program1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("nhap x:");
		double x =sc.nextDouble();
		System.out.println("nhap y:");
		double y =sc.nextDouble();
		sc.nextLine();
		System.out.println("nhap ten thanh pho:");
		String ten =sc.nextLine();
		
		ToaDo toado = new ToaDo(x, y, ten); 
		System.out.println("Use getThongTin:");
		System.out.println(toado.getThongTin());
		System.out.println("Use toString:");
		System.out.println(toado.toString());
	}
}
