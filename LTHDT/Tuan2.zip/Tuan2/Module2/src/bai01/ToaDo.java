package bai01;

public class ToaDo {
	private double x;
	private double y;
	private String ten;
	public ToaDo() {
		x = 0;
		y = 0;
		ten = "HCM";
	}
	public ToaDo(double x, double y,String ten) {
		this.x = x;
		this.y = y;
		this.ten = ten;
	}
	public double getx() {
		return x;
	}
	public void setx(double x) {
		this.x = x;
	}
	public double gety() {
		return y;
	}
	public void sety(double y) {
		this.y = y;
	}
	public String getTen() {
		return ten;
	}
	public void setTen(String ten) {
		this.ten = ten;
	}
	public String getThongTin() {
		return String.format("%s(%.0f,%.0f)", ten, x, y);
	}
	public String toString(){
		return ten + "(" + x +"," + y + ")";
		
	}
}
