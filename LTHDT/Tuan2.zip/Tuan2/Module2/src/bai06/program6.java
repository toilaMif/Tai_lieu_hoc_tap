package bai06;

public class program6 {
	 public static void main(String[] args) throws Exception {
	   
	            ThongTinDangKyXe xe1 = new ThongTinDangKyXe();
	            xe1 = new ThongTinDangKyXe("Nguyen Thanh Trung", "Xe 1", 10000000, 90);
	            ThongTinDangKyXe xe2 = new ThongTinDangKyXe();
	            xe2 = new ThongTinDangKyXe("Thai Van Trung", "Xe 2", 20000000, 150);
	            ThongTinDangKyXe xe3 = new ThongTinDangKyXe();
	            xe3 = new ThongTinDangKyXe("Thạch Đa Ril", "Xe 3", 30000000, 250);

	           System.out.printf("%20s %20s %20s %20s %20s", "Tên chủ xe", "Loại xe", "Dung Tích", "Trị Giá", "Thuế Phải nộp");
	           System.out.println("\n====================================================================================================================================");
	           System.out.println(xe1.toString());
	           System.out.println(xe2.toString());
	           System.out.println(xe3.toString());
}
}