package bai06;

import java.awt.Font;

public class ThongTinDangKyXe {
	 private String chuXe;
	    private String loaiXe;
	    private double triGiaXe;
	    private double dungTichXyLanh;

	    public ThongTinDangKyXe() {
	        this.chuXe = "";
	        this.loaiXe = "";
	        this.triGiaXe = 0;
	        this.dungTichXyLanh = 0;
	    }

	    public ThongTinDangKyXe(String chuXe, String loaiXe, double triGiaXe, double dungTichXyLanh) throws Exception {
	        if (triGiaXe < 0 || dungTichXyLanh < 0) {
	            throw new Exception("Gia tri khong hop le!");
	        }
	        this.chuXe = chuXe;
	        this.loaiXe = loaiXe;
	        this.triGiaXe = triGiaXe;
	        this.dungTichXyLanh = dungTichXyLanh;
	    }

	    public double tinhThue() {
	        if (dungTichXyLanh < 100) {
	            return triGiaXe * 0.01;
	        } else if (dungTichXyLanh <= 200) {
	            return triGiaXe * 0.03;
	        } else {
	            return triGiaXe * 0.05;
	        }
	    }

	    @Override
	    public String toString() {
	        return String.format("%20s %20s %20.2f %20.2f %20.2f", chuXe, loaiXe, dungTichXyLanh, triGiaXe, tinhThue());
	    }

}
