package bai05;

public class Program5 {
	public static void main(String[] args) {
		Triangle tamgiac1 = new Triangle();
		tamgiac1 = new Triangle(-1, 2, 3); 
		
		Triangle tamgiac2 = new Triangle();
		tamgiac2 = new Triangle(1, 2, 3); 
		
		Triangle tamgiac3 = new Triangle();
		tamgiac3 = new Triangle(3, 4, 5); 
		
		Triangle tamgiac4 = new Triangle();
		tamgiac4 = new Triangle(5, 5, 7); 
		
		Triangle tamgiac5 = new Triangle();
		tamgiac5 = new Triangle(5, 5, 5); 
		
		System.out.println("tamgiac1: " + tamgiac1.toString());
		System.out.println("tamgiac2: " +tamgiac2.toString());
		System.out.println("tamgiac3: " +tamgiac3.toString());
		System.out.println("tamgiac4: " +tamgiac4.toString());
		System.out.println("tamgiac5: " +tamgiac5.toString());
	}
}
