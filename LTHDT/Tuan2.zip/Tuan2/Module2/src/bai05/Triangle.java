package bai05;

public class Triangle {
	private double ma, mb, mc;

    public Triangle() {
        this.ma = 0;
        this.mb = 0;
        this.mc = 0;
    }

    public Triangle(double ma, double mb, double mc) {
        if (ma < 0 || mb < 0 || mc < 0 || ma + mb <= mc || ma + mc <= mb || mb + mc <= ma) {
            this.ma = 0;
            this.mb = 0;
            this.mc = 0;
        } else {
            this.ma = ma;
            this.mb = mb;
            this.mc = mc;
        }
    }

    public double getMa() {
        return ma;
    }

    public void setMa(double ma) {
        if (ma >= 0 && ma + mb > mc && ma + mc > mb) {
            this.ma = ma;
        }
    }

    public double getMb() {
        return mb;
    }

    public void setMb(double mb) {
        if (mb >= 0 && ma + mb > mc && mb + mc > ma) {
            this.mb = mb;
        }
    }

    public double getMc() {
        return mc;
    }

    public void setMc(double mc) {
        if (mc >= 0 && ma + mc > mb && mb + mc > ma) {
            this.mc = mc;
        }
    }

    public double getPerimeter() {
        return ma + mb + mc;
    }

    public double getArea() {
        double p = getPerimeter() / 2;
        return Math.sqrt(p * (p - ma) * (p - mb) * (p - mc));
    }

    public String getTriangleType() {
        if (ma == mb && mb == mc && (ma != 0 && mb != 0 && mc != 0)) {
            return "Tam Giac Deu";
        } else if ((ma == mb || ma == mc || mb == mc) && (ma != 0 && mb != 0 && mc != 0)) {
            return "Tam Giac can";
        } else if (ma + mb <= mc || ma + mc <= mb || mb + mc <= ma || ma == 0 || mb == 0 || mc == 0) {
            return "khong phai tam giac";
        } else {
            return "Tam Giac thưong";
        }
    }

    @Override
    public String toString() {
        return 
                "ma=" + ma +
                ", mb=" + mb +
                ", mc=" + mc +
                ", Kieu: '" + getTriangleType() + '\'' +
                ", Chu_Vi= " + getPerimeter() +
                ", Dien_Tich= " + getArea() 
                ;
    }
}
