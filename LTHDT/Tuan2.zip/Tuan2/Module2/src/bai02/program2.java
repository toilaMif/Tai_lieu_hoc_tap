package bai02;

import java.util.Scanner;

public class program2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("nhap x:");
		double x =sc.nextDouble();
		System.out.println("nhap y:");
		double y =sc.nextDouble();
		
		Point point = new Point(x, y);
		System.out.println("toa do point: " + point.toString());
		point.negate();
		System.out.println("toa do point doi xung qua goc toa do O: " + point.toString());
		System.out.println("khoang cach tu goc O: " + point.getDistance());
		
		
	}
}
