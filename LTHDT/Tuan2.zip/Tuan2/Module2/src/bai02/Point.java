package bai02;

public class Point {
	private double x;
	private double y;
	public void point() {
		x = 0;
		y = 0;
	} 
	public Point(double x, double y) {
		this.x = x;
		this.y = y;
	}
	public void negate() {
		this.x = -x;
		this.y = -y;
	}
	public double getDistance(){
		return Math.sqrt(x*x+y*y);
		
	}
	public String toString() {
		return "(" + x + "," + y + ")";
		
	}
}
