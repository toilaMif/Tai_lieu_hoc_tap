package bai09;

import java.util.Scanner;

public class Program9 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("nhap ten toa do:");
		String ten =sc.nextLine();
		System.out.println("nhap toa do x:");
		float x =sc.nextFloat();
		System.out.println("nhap toa do y:");
		float y =sc.nextFloat();
		System.out.println("nhap ban kinh:");
		double banKinh =sc.nextDouble();
		sc.nextLine();
		
		ToaDo toado = new ToaDo(ten, x, y);
		HinhTron hinhtron = new HinhTron(toado, banKinh);
		System.out.println(hinhtron.toString());
	}
}
