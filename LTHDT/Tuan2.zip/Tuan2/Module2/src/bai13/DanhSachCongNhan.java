package bai13;

public class DanhSachCongNhan {
    private CongNhan[] congNhans;
    private int count = 0;

    public DanhSachCongNhan(int n) {
        congNhans = new CongNhan[n];
    }

    public void themCongNhan(CongNhan congNhan) {
        if (count < congNhans.length) {
            congNhans[count++] = congNhan;
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            sb.append("Công nhân " + (i + 1) + ":\n");
            sb.append("Họ: " + congNhans[i].getmHo() + "\n");
            sb.append("Tên: " + congNhans[i].getmTen() + "\n");
            sb.append("Số sản phẩm: " + congNhans[i].getmSoSP() + "\n");
            sb.append("Lương: " + congNhans[i].tinhLuong() + "\n");
            sb.append("--------------------\n");
        }
        return sb.toString();
    }


    public int soLuongCongNhan() {
        return count;
    }

    public void xoaCongNhan(int maCn) {
        for (int i = 0; i < count; i++) {
            if (i+1 == maCn) {
                for (int j = i; j < count - 1; j++) {
                    congNhans[j] = congNhans[j + 1];
                }
                congNhans[--count] = null;
                break;
            }
        }
    }

    public DanhSachCongNhan congNhanLamTren200SP() {
        DanhSachCongNhan ds = new DanhSachCongNhan(count);
        for (int i = 0; i < count; i++) {
            if (congNhans[i].getmSoSP() > 200) {
                ds.themCongNhan(congNhans[i]);
            }
        }
        return ds;
    }

    public void sapXepGiamDanTheoSoSP() {
        for (int i = 0; i < count - 1; i++) {
            for (int j = i + 1; j < count; j++) {
                if (congNhans[i].getmSoSP() < congNhans[j].getmSoSP()) {
                    CongNhan temp = congNhans[i];
                    congNhans[i] = congNhans[j];
                    congNhans[j] = temp;
                }
            }
        }
    }
}
