package bai13;

public class CongNhan {
    private String mHo;
    private String mTen;
    private int mSoSP;

    public CongNhan(String mHo, String mTen, int mSoSP) {
        this.mHo = mHo;
        this.mTen = mTen;
        this.mSoSP = mSoSP;
    }

    public String getmHo() {
        return mHo;
    }

    public void setmHo(String mHo) {
        this.mHo = mHo;
    }

    public String getmTen() {
        return mTen;
    }

    public void setmTen(String mTen) {
        this.mTen = mTen;
    }

    public int getmSoSP() {
        return mSoSP;
    }

    public void setmSoSP(int mSoSP) {
        this.mSoSP = mSoSP;
    }

    public double tinhLuong() {
        double donGia;
        if (mSoSP < 200) {
            donGia = 0.5;
        } else if (mSoSP < 400) {
            donGia = 0.55;
        } else if (mSoSP < 600) {
            donGia = 0.6;
        } else {
            donGia = 0.65;
        }
        return mSoSP * donGia;
    }
}
