package bai13;

import java.util.Scanner;

public class progran13 {
	public static void main(String[] args) {
        DanhSachCongNhan ds = new DanhSachCongNhan(5);
        ds.themCongNhan(new CongNhan("Nguyen", "A", 100));
        ds.themCongNhan(new CongNhan("Tran", "B", 300));
        ds.themCongNhan(new CongNhan("Le", "C", 500));
        ds.themCongNhan(new CongNhan("Pham", "D", 700));
        ds.themCongNhan(new CongNhan("Hoang", "E", 900));
        
        Scanner scanner = new Scanner(System.in);
        int choice;
        do {
            System.out.println("1. Thêm CN");
            System.out.println("2. Lấy số lượng công nhân có trong danh sách");
            System.out.println("3. xóa công nhân");
            System.out.println("4. Danh sách công nhân làm trên 200 sản phẩm");
            System.out.println("5. Sắp xếp công nhân theo số sản phẩm giảm dần");
            System.out.println("6. Xem thông tin Danh sách công nhân");
            System.out.println("0. Thoát");
            System.out.print("Nhập lựa chọn của bạn: ");
            choice = scanner.nextInt();

            switch (choice) {
            case 1:
                // Thêm CN
                System.out.println("Nhập họ: ");
                String ho = scanner.next();
                System.out.println("Nhập tên: ");
                String ten = scanner.next();
                System.out.println("Nhập số sản phẩm: ");
                int soSP = scanner.nextInt();
                CongNhan cn = new CongNhan(ho, ten, soSP);
                ds.themCongNhan(cn);
                break;
            case 2:
                // Lấy số lượng công nhân có trong danh sách
                System.out.println("Số lượng công nhân trong danh sách: " + ds.soLuongCongNhan());
                break;
            case 3:
                // Xóa công nhân
                System.out.println("Nhập ma công nhân cần xóa: ");
                int maCN = scanner.nextInt();
                ds.xoaCongNhan(maCN);
                break;
            case 4:
                // Danh sách công nhân làm trên 200 sản phẩm
                DanhSachCongNhan ds200 = ds.congNhanLamTren200SP();
                System.out.println("Danh sách công nhân làm trên 200 sản phẩm: ");
                System.out.println(ds200.toString());
                break;
            case 5:
                // Sắp xếp công nhân theo số sản phẩm giảm dần
                ds.sapXepGiamDanTheoSoSP();
                System.out.println("Danh sách sau khi sắp xếp giảm dần theo số sản phẩm: ");
                System.out.println(ds.toString());
                break;
            case 6:
                // Xem thông tin Danh sách công nhân
                System.out.println("Thông tin của tất cả các công nhân trong danh sách: ");
                System.out.println(ds.toString());
                break;
            case 0:
                System.out.println("Thoát chương trình.");
                break;
            default:
                System.out.println("Lựa chọn không hợp lệ. Vui lòng thử lại.");
        }


        } while (choice != 0);

        scanner.close();
    }
   }

