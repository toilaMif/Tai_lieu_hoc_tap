package bai16;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

public class Program16 {
	public static void main(String[] args) {
        // Tạo và khởi tạo một số học viên
        HocVien hocVien1 = new HocVien("Nguyen Van A", "123 Duong X", "123456789");
        HocVien hocVien2 = new HocVien("Tran Thi B", "456 Duong Y", "987654321");
        HocVien hocVien3 = new HocVien("Le Van C", "789 Duong Z", "555555555");

        // Tạo và khởi tạo một số khóa học
        KhoaHoc khoaHoc1 = new KhoaHoc("Java Programming", LocalDate.of(2022, 1, 1), "18:00 - 20:00");
        KhoaHoc khoaHoc2 = new KhoaHoc("Web Development", LocalDate.of(2022, 2, 1), "20:00 - 22:00");

        // Thêm học viên vào danh sách khóa học
        khoaHoc1.themHocVien(hocVien1);
        khoaHoc1.themHocVien(hocVien2);
        khoaHoc2.themHocVien(hocVien3);

        // Hiển thị thông tin các khóa học
        hienThiThongTinKhoaHoc(khoaHoc1);
        hienThiThongTinKhoaHoc(khoaHoc2);

        // Tìm kiếm khóa học theo tên
        KhoaHoc khoaHocTimKiem = timKhoaHocTheoTen("Java Programming", Arrays.asList(khoaHoc1, khoaHoc2));
        if (khoaHocTimKiem != null) {
            System.out.println("Tim thay khóa học: " + khoaHocTimKiem.getTenKhoaHoc());
        } else {
            System.out.println("Không tim thay khóa học.");
        }

        // Kiểm tra trạng thái khóa học
        kiemTraTrangThaiKhoaHoc(khoaHoc1);
        kiemTraTrangThaiKhoaHoc(khoaHoc2);
    }

    // Hiển thị thông tin của một khóa học
    private static void hienThiThongTinKhoaHoc(KhoaHoc khoaHoc) {
        System.out.println("Thông tin khóa học: " + khoaHoc.getTenKhoaHoc());
        System.out.println("Ngày mở khóa học: " + khoaHoc.getNgayMo());
        System.out.println("Thời gian học: " + khoaHoc.getThoiGianHoc());
        System.out.println("Danh sách học viên:");
        for (HocVien hocVien : khoaHoc.getDanhSachHocVien()) {
            System.out.println("- " + hocVien.getHoTen());
        }
        System.out.println("------------------------");
    }

    // Tìm kiếm khóa học theo tên
    private static KhoaHoc timKhoaHocTheoTen(String tenKhoaHoc, List<KhoaHoc> danhSachKhoaHoc) {
        for (KhoaHoc khoaHoc : danhSachKhoaHoc) {
            if (khoaHoc.getTenKhoaHoc().equals(tenKhoaHoc)) {
                return khoaHoc;
            }
        }
        return null;
    }

    // Kiểm tra trạng thái của một khóa học
    private static void kiemTraTrangThaiKhoaHoc(KhoaHoc khoaHoc) {
        System.out.println("Trạng thái khóa học '" + khoaHoc.getTenKhoaHoc() + "':");
        if (khoaHoc.daKetThuc()) {
            System.out.println("Khóa học đã kết thúc.");
        } else if (khoaHoc.chuaBatDau()) {
            System.out.println("Khóa học chưa bắt đầu.");
        } else {
            System.out.println("Khóa học đang diễn ra.");
        }
        System.out.println("------------------------");
    }

	
}


