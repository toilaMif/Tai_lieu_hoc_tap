package bai16;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class KhoaHoc {
	private String tenKhoaHoc;
    private LocalDate ngayMo;
    private String thoiGianHoc;
    private List<HocVien> danhSachHocVien;

    public KhoaHoc(String tenKhoaHoc, LocalDate ngayMo, String thoiGianHoc) {
        this.tenKhoaHoc = tenKhoaHoc;
        this.ngayMo = ngayMo;
        this.thoiGianHoc = thoiGianHoc;
        this.danhSachHocVien = new ArrayList<>();
    }

    public String getTenKhoaHoc() {
        return tenKhoaHoc;
    }

    public LocalDate getNgayMo() {
        return ngayMo;
    }

    public String getThoiGianHoc() {
        return thoiGianHoc;
    }

    public List<HocVien> getDanhSachHocVien() {
        return danhSachHocVien;
    }

    public void themHocVien(HocVien hocVien) {
        danhSachHocVien.add(hocVien);
    }

    public boolean daKetThuc() {
        // Giả sử khóa học kết thúc sau 1 tháng mở
        return LocalDate.now().isAfter(ngayMo.plusMonths(1));
    }

    public boolean chuaBatDau() {
        return LocalDate.now().isBefore(ngayMo);
    }
}
